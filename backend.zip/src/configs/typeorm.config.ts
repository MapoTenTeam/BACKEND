import { TypeOrmModuleOptions } from '@nestjs/typeorm';

export const typeORMConfig: TypeOrmModuleOptions = {
  type: 'mysql',
  // host: '121.162.15.140',
  // username: 'myjob',
  // password: 'Mapo10$$',
  // database: 'myjob',
  // port: 3306,

  // DATABASE_HOST=localhost
  // DATABASE_PORT=3306
  // DATABASE_USERNAME=root
  // DATABASE_PASSWORD=987654321
  // DATABASE_DATABASE=board-app6

  // DATABASE_HOST=121.162.15.140
  // DATABASE_PORT=3306
  // DATABASE_USERNAME=myjob
  // DATABASE_PASSWORD=Mapo10$$
  // DATABASE_DATABASE=myjob
  host: 'localhost',
  username: 'root',
  password: '987654321',
  database: 'board-app6',
  entities: [__dirname + '/../**/*.entity{.ts,.js}'],
  synchronize: true,
  logging: true,
};
